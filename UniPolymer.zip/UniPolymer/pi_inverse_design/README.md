# PI Inverse Design

This module generates polyimide repeat-unit SMILES conditioned on a target glass transition temperature (Tg).

## Structure

```text
pi_inverse_design/
├── data/
│   ├── raw/data/PI_Tg_10066.csv
│   ├── raw/data/data.xlsx
│   └── processed/
│       ├── train_augmented.pkl
│       ├── val.pkl
│       ├── vocab.json
│       └── stats.json
├── src/
│   ├── preprocess.py
│   ├── dataset.py
│   ├── model.py
│   ├── train.py
│   ├── generate.py
│   ├── evaluate.py
│   └── forward_model.py
├── checkpoints/
├── results/
└── requirements.txt
```

## Install

```bash
pip install -r requirements.txt
```

## Reproduce Data Processing

`data/raw/data/data.xlsx` is converted from the unified `PI_Tg_10066.csv`
source data. It contains 10066 raw rows. The current preprocessing pipeline
keeps the unique structures that RDKit validates and SELFIES can encode.

```bash
python src/preprocess.py \
  --data data/raw/data/data.xlsx \
  --out_dir data/processed \
  --augment_n 8 \
  --n_bins 20
```

## Train the Forward Evaluator

```bash
python src/forward_model.py --data data/raw/data/data.xlsx
```

## Train the Generator

```bash
python src/train.py \
  --processed_dir data/processed \
  --d_model 256 \
  --num_dec_layers 4 \
  --epochs 200 \
  --batch_size 64 \
  --patience 20
```

## Generate Candidates

```bash
python src/generate.py \
  --tg_target 300 \
  --n_samples 100 \
  --temperature 1.0 \
  --top_p 0.9 \
  --out results/generated_300.csv
```

The packaged checkpoint is used by default.

## Evaluate

```bash
python src/evaluate.py \
  --tg_targets 200 250 300 350 400 \
  --n_samples 100 \
  --out results/evaluation_report.csv
```

## Python API

```python
from src.generate import generate_batch, load_model

model, vocab, inv_vocab, stats = load_model(
    "checkpoints/reverse_20260318_232126/best_model_valloss_0.9011.pt"
)

output = generate_batch(
    model=model,
    tg_target=320,
    vocab=vocab,
    inv_vocab=inv_vocab,
    stats=stats,
    n_samples=100,
    temperature=1.0,
    top_p=0.9,
)
```
