# UniPolymer Package Manifest

This package is organized as a reproducible release for PI Tg prediction,
target-conditioned inverse design, and the web interface.

## Root Files

- `README.md`: setup, data usage, model usage, and run instructions.
- `requirements.txt`: Python dependencies for the model code and web backend.
- `.gitattributes`: Git LFS tracking rules for large artifacts.
- `.gitignore`: local caches, training outputs, and frontend build outputs.
- `scripts/check_package.py`: verifies required release files.

## Forward Prediction

- `pi_forward_prediction/data/PI_Tg_10066.csv`: unified source transfer dataset.
- `pi_forward_prediction/data/PI_Tg_10066_with_desc_p1_m128.csv`: full descriptor table used by the forward config.
- `pi_forward_prediction/data/PI_Tg_10066_holdout80_p1_m128.csv`: deterministic 80-row holdout table.
- `pi_forward_prediction/data/`: compatibility copies and tokenizer vocabulary files.
- `pi_forward_prediction/experiments/config/p26_runs/kfold_m128_head15.yaml`: default Tg model configuration.
- `pi_forward_prediction/ckpt/experiments/full/contrastive_roberta/`: packaged contrastive backbone.
- `pi_forward_prediction/ckpt/experiments/p26/kfold_m128_head15/PI_Tg_best_model.pt`: packaged PI Tg checkpoint.
- `pi_forward_prediction/Downstream.py`: training and checkpoint-loading entry point.

## Inverse Design

- `pi_inverse_design/data/raw/data/PI_Tg_10066.csv`: source dataset copy.
- `pi_inverse_design/data/raw/data/data.xlsx`: source dataset converted to the inverse-design schema.
- `pi_inverse_design/data/processed/`: processed SELFIES dataset and vocabulary generated from `data.xlsx`.
- `pi_inverse_design/checkpoints/reverse_20260318_232126/best_model_valloss_0.9011.pt`: packaged generator checkpoint.
- `pi_inverse_design/checkpoints/forward_20260318_232230/forward_model_best_r2_0.8535.pkl`: packaged forward evaluator.
- `pi_inverse_design/src/generate.py`: target-Tg-conditioned generation entry point.

## Web App

- `web/prediction/backend/`: FastAPI backend for Tg prediction and inverse design.
- `web/prediction/frontend/`: Vue frontend source and npm lockfile.
- `web/prediction/scripts/start-web.sh`: starts backend and frontend together.

## Large Files

The package includes model and dataset artifacts larger than GitHub's normal
file-size limit. Initialize Git LFS before committing:

```bash
git lfs install
git lfs track "*.pt" "*.bin" "*.safetensors" "*.pkl" "*.joblib" "*.xlsx" "*.png"
```
